package com.safeanchor;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class Config {
    public static Config I = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("safeanchor.json"); }

    public static void load() {
        try { if (Files.exists(file())) { Config c = GSON.fromJson(Files.readString(file()), Config.class); if (c != null) I = c; } }
        catch (Exception ignored) {}
    }
    public static void save() { try { Files.writeString(file(), GSON.toJson(I)); } catch (Exception ignored) {} }

    // ---- chung ----
    public boolean enabled = true;
    public boolean showTitle = true;
    public boolean autoTotem = false;
    public int totemSlot = 5;      // ô hotbar chứa totem (1-9)
    public int spareSlot = 8;      // ô hotbar tạm để đổi đồ từ túi (1-9)
    public double reach = 4.5;

    // ---- elytra mace ----
    public boolean autoMace = false;
    public int maceView = 0;       // 0 giữ nguyên, 1 ngôi 1, 2 ngôi 3 sau, 3 ngôi 3 trước
    public double maceRange = 64;
    public double maceDiveDist = 12;
    public double maceHorizDive = 14;
    public double maceSwapDist = 14;   // còn cách đối thủ bao nhiêu block thì đổi cánh -> áo để rơi đập
    public double maceAbortDist = 10;  // đối thủ lệch ngang quá số này (pearl/chạy) thì bỏ, bay lên lại
    public double minSelfHealth = 6;
    public boolean maceSwapChest = true;
    public boolean maceUseRocket = true;

    // ---- crystal / pearl ----
    public boolean crystal = false;
    public boolean crystalAutoObs = true;
    public boolean pearlCrystal = true;
    public double crystalRange = 4.5;
    public double crystalExplodeDist = 5.0;
    public double maxSelfDamage = 8;
    public int crystalDelay = 2;

    // ---- anchor ----
    public boolean anchor = false;
    public boolean anchorSafe = true;

    // ---- esp ----
    public boolean espPlayers = false, espMobs = false, espStorage = false, espBlocks = false;
    public int espMode = 2;        // 0 viền, 1 đặc, 2 cả hai
    public int espAlpha = 90;
    public double espRange = 128;
    public int espPlayerColor = 0xFF10F0, espMobColor = 0xFFA040, espChestColor = 0xE0B040,
            espEnderColor = 0xA040FF, espShulkerColor = 0xFF60C0;
    // dây tracer: 0 tắt, 1 trên màn hình, 2 giữa màn hình, 3 dưới màn hình
    public int trPlayer = 3, trMob = 0, trChest = 0, trEnder = 0, trShulker = 0, trBlock = 0;
    public boolean tracerOwnColor = false;
    public int tracerColor1 = 0xFFFFFF, tracerColor2 = 0x00FFFF, tracerColor3 = 0xFF69B4;

    // ---- pearl phát sáng ----
    public boolean pearlGlow = true;
    public int pearlGlowColor = 0xFF10F0;

    // ---- quỹ đạo ném / cung, máu, schematic, dây ----
    public boolean trajOn = true, healthTag = false, schemGhost = true;
    public int tracerOffset = 0;      // kéo dây lên/xuống (-80..80)

    // ---- aimbot ----
    public boolean aimbot = false, aimCircle = true, aimPlayers = true, aimVisibleOnly = true;
    public double aimFov = 25;       // bán kính vòng tròn (độ)
    public double aimRange = 30;
    public double aimSmooth = 0.35;  // 0.05 chậm - 1 khóa ngay
    public int aimColor = 0xFF69B4;

    // ---- block esp ----
    public boolean espBlkOres = true, espBlkUtility = false, espBlkSpecial = true;
    public int espBlkOreColor = 0x40E0FF, espBlkUtilityColor = 0xC0C0C0, espBlkSpecialColor = 0xFF4040, espBlkCustomColor = 0x40FF40;
    public double espBlkRange = 48;
    public List<String> espBlkCustom = new ArrayList<>();

    // ---- hud ----
    public boolean counterOn = false;
    public int counterX = 1, counterY = 12;       // phần trăm màn hình
    public boolean radarOn = false, radarPlayers = true, radarBlocks = true;
    public int radarX = 99, radarY = 12, radarSize = 90;
    public double radarRange = 48;

    // ---- printer (schematic) ----
    public boolean printerOn = false;
    public int printerDelay = 2;
    public int printerPerTick = 1;
    public double printerRange = 4.5;
    public boolean printerFixRotate = true;
    public boolean printerClicks = true;
    public boolean printerSneak = true;
}
