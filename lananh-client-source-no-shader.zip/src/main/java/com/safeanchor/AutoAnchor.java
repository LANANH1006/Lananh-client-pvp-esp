package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Đặt anchor xong: tự đặt obsidian chắn (nếu có) -> nạp glowstone -> đổi sang ô totem -> nổ. */
public class AutoAnchor {
    static BlockPos anchor; static int phase, wait, fail, quiet;

    public static void toggle(MinecraftClient mc) {
        Config.I.anchor = !Config.I.anchor; Config.save();
        Util.msg("Safe Anchor: " + (Config.I.anchor ? "§aBẬT" : "§cTẮT"));
    }

    public static void onPlace(BlockHitResult hit) {
        if (!Config.I.anchor || !Config.I.enabled) return;
        if (anchor != null || quiet > 0) return;
        var w = MinecraftClient.getInstance().world;
        if (w.getBlockState(hit.getBlockPos()).isOf(Blocks.RESPAWN_ANCHOR)) return;
        BlockPos pos = w.getBlockState(hit.getBlockPos()).isReplaceable() ? hit.getBlockPos() : hit.getBlockPos().offset(hit.getSide());
        anchor = pos; phase = 0; wait = 2; fail = 0;
    }

    static void reset() { anchor = null; phase = 0; quiet = 12; }

    /** Phím: tự đặt anchor ngay chỗ đối thủ gần nhất rồi nạp + nổ. */
    public static void bomb(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (p == null || w == null || anchor != null) return;
        PlayerEntity t = Util.nearestEnemy(8);
        if (t == null) { Util.warn("Không có đối thủ gần!"); return; }
        if (!Util.has(s -> s.isOf(Items.RESPAWN_ANCHOR))) { Util.warn("Không có anchor!"); return; }
        BlockPos tp = t.getBlockPos(), pick = null; double bd = 1e9;
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) for (int dy = 0; dy <= 1; dy++) {
            BlockPos q = tp.add(dx, dy, dz);
            if (!w.getBlockState(q).isReplaceable()) continue;
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(q)) > c.reach) continue;
            if (!w.getOtherEntities(null, new Box(q)).isEmpty()) continue;
            double d = Vec3d.ofCenter(q).distanceTo(t.getPos());
            if (d < bd) { bd = d; pick = q; }
        }
        if (pick == null) { Util.warn("Không có chỗ đặt anchor cạnh đối thủ!"); return; }
        if (Util.placeBlock(pick, Items.RESPAWN_ANCHOR)) { anchor = pick; phase = 0; wait = 2; fail = 0; }
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (quiet > 0) quiet--;
        if (anchor == null || !c.anchor || p == null || w == null) return;
        if (wait > 0) { wait--; return; }
        if (!w.getBlockState(anchor).isOf(Blocks.RESPAWN_ANCHOR)) { if (++fail > 20) reset(); return; }
        if (p.getEyePos().distanceTo(anchor.toCenterPos()) > c.reach + 1) { reset(); return; }

        switch (phase) {
            case 0 -> {
                if (c.anchorSafe && Util.has(s -> s.isOf(Items.OBSIDIAN))) {
                    double dx = p.getX() - (anchor.getX() + 0.5), dz = p.getZ() - (anchor.getZ() + 0.5);
                    Direction d = Direction.getFacing(dx, 0, dz);
                    BlockPos shield = anchor.offset(d);
                    if (w.getBlockState(shield).isReplaceable()) Util.placeBlock(shield, Items.OBSIDIAN);
                }
                phase = 1; wait = 1;
            }
            case 1 -> {
                int ch = w.getBlockState(anchor).get(Properties.CHARGES);
                if (ch < 1) {
                    if (!Util.selectItem(s -> s.isOf(Items.GLOWSTONE))) { Util.warn("Không có glowstone!"); reset(); return; }
                    Util.useOnBlock(anchor, Direction.UP);
                }
                phase = 2; wait = 1;
            }
            case 2 -> {
                if (w.getBlockState(anchor).get(Properties.CHARGES) < 1) { if (++fail > 10) reset(); wait = 1; return; }
                Util.select(c.totemSlot - 1);              // đổi sang ô totem rồi kích nổ
                Util.useOnBlock(anchor, Direction.UP);
                reset();
            }
            default -> reset();
        }
    }
}
